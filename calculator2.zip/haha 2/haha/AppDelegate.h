//
//  AppDelegate.h
//  haha
//
//  Created by notered234 on 2015/4/27.
//  Copyright (c) 2015年 notered234. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

